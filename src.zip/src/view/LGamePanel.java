package view;

import java.awt.Graphics;
import java.util.Vector;

import javax.swing.JPanel;

import element.LElement;

public class LGamePanel  extends JPanel{
	Vector<LElement> element;
	
	public void setElement(Vector<LElement> e){
		element = e;
	}
	
	public void paintComponent(Graphics g){
		if(element != null)
			for(LElement e : element)
				{e.draw(g);}
	}
}
