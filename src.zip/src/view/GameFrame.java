package view;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.*;

public class GameFrame extends JFrame{
	private final String START_TITAL_NAME = "GAME";
	final int TOTAL_HEIGHT = 640;
	final int TOTAL_WIDTH = 940;
	
	
	public GameFrame()
	{
		setFrame(this);
		repaint();
	}
	
	private void setFrame(JFrame f)
	{
		f.setSize(TOTAL_WIDTH, TOTAL_HEIGHT);
		f.setTitle(START_TITAL_NAME);
		setResizable(false);
		f.setVisible(true);
		f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		Dimension scrSize=Toolkit.getDefaultToolkit().getScreenSize(); 
		if( scrSize.height >= TOTAL_HEIGHT  && scrSize.width >= TOTAL_WIDTH)
		{
			f.setLocation((scrSize.width - TOTAL_WIDTH)/2, (scrSize.height - TOTAL_HEIGHT) / 2); 
		}
		else
		{
			f.setLocation(0,0);
			JOptionPane.showConfirmDialog(this, "YOU NEED A BIGGER SCREEN!", "WARNING", JOptionPane.YES_OPTION);
		}
		
	}
	
	
	
	
}
