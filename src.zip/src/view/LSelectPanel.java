package view;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Vector;

import javax.swing.*;

import element.LElement;

public class LSelectPanel extends JPanel{
	
	Vector<LElement> backgroundelement;
	
	Vector<LElement> element;
	
	Vector<LElement> coverelement;
	
	private boolean paintfinish;
	
	public void setElement(Vector<LElement> e){
		element = e;
	}
	public void setBackgroundElement(Vector<LElement> e){
		backgroundelement = e;
	}
	public void setcoverelement(Vector<LElement> e){
		coverelement = e;
	}
	
	public LSelectPanel()
	{
		paintfinish = true;
	}
	
	public void paintComponent(Graphics g){
		
		if(paintfinish)
		{
			paintfinish = false;
			
			paintElement(backgroundelement, g);
			paintElement(element, g);
			paintElement(coverelement, g);
			
			
			paintfinish = true;
		}
	}
	
	private void paintElement(Vector<LElement> someelement, Graphics g)
	{
		if(someelement != null)
		{
			Vector<LElement> remove = new Vector<LElement>();
			
			for(LElement e : someelement)
			{
				if(e != null && e.visible)
				{
					e.draw(g);
				}
				else
				{	
					remove.add(e);
				}
			}
			someelement.removeAll(remove);
		}
	}
	
	public boolean paintfinish()
	{
		return paintfinish;
	}
}
