package element;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.json.JSONException;
import org.json.JSONObject;

public class LShape implements ImageObserver {
	
	private int points[];
	private ShapeType type;
	private int fillkind;
	private String str;
	private Image image = null;
	private Color color;
	private String font;
	
	public enum ShapeType{rect, line, oval, arc, img, str};
	
	public void drawOn(Graphics g, int x, int y){		
		
		if(type != ShapeType.img)
			g.setColor(color);
		switch (type)
		{
		case rect:
			g.fillRect(x + points[0], y + points[1], points[2], points[3]);
			return;
			
		case line:
			g.drawLine(x + points[0], y + points[1], points[2], points[3]);
			return;
			
		case oval:
			g.fillOval(x + points[0], y + points[1], points[2], points[3]);
			return;
			
		case arc :
			g.drawArc(x + points[0], y + points[1], points[2], points[3], points[4], points[5]);
			return;
			
		case str :
			g.setFont(new Font(font, points[0], points[1]));
			g.drawString(str, x, y);
			
		case img :
			g.drawImage(image, x + points[0], y + points[1], this);
			return;
			
		}
	}

	public boolean imageUpdate(Image arg0, int arg1, int arg2, int arg3, int arg4, int arg5) 
	{
		// TODO Auto-generated method stub
		return true;
	}
	public LShape(JSONObject input) throws FileNotFoundException, JSONException, IOException {
		// TODO Auto-generated method stub
		switch(input.getString("shapetype"))
		{
		case "img" :
			type = ShapeType.img;
			image = ImageIO.read(new FileInputStream(new File(input.getString("filename"))));
			points = new int[2];
			points[0] = input.getInt("x");
			points[1] = input.getInt("y");
			return;
		case "rect":
			type = ShapeType.rect;
			points = new int[4];
			points[0] = input.getInt("p0");
			points[1] = input.getInt("p1");
			points[2] = input.getInt("p2");
			points[3] = input.getInt("p3");
			break;
		case "line":
			type = ShapeType.line;
			points = new int[4];
			points[0] = input.getInt("p0");
			points[1] = input.getInt("p1");
			points[2] = input.getInt("p2");
			points[3] = input.getInt("p3");
			break;
		case "oval":
			type = ShapeType.oval;
			points = new int[4];
			points[0] = input.getInt("p0");
			points[1] = input.getInt("p1");
			points[2] = input.getInt("p2");
			points[3] = input.getInt("p3");
			break;
		case "arc" :
			type = ShapeType.arc;
			points = new int[6];
			points[0] = input.getInt("p0");
			points[1] = input.getInt("p1");
			points[2] = input.getInt("p2");
			points[3] = input.getInt("p3");
			points[4] = input.getInt("p4");
			points[5] = input.getInt("p5");
			break;
		case "str" :
			type = ShapeType.str;
			str = input.getString("str");
			font = input.getString("font");
			points = new int[2];
			points[0] = input.getInt("style");
			points[1] = input.getInt("size");
			break;
		}
		color = new Color(input.getInt("red"), input.getInt("green"), input.getInt("blue"));
		
	}
}
