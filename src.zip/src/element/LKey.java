package element;

public class LKey {
	public final static int SPACE = 32;
	public final static int ENTER = 10;
	public final static int ESC = 27;
	public final static int SHIFT = 16;
	public final static int Z_KEY = 90;
	public final static int X_KEY = 88;
	public final static int DOWN = 40;
	public final static int UP = 38;
	public final static int RIGHT = 39;
	public final static int LEFT = 37;
	
	
	final int[] desp_f;
	final int[] desp_s;
	public final int keycode;
	
	public boolean isdown;
	
	public LKey(int a, int b, int c, int d, int e)
	{
		desp_f = new int[2];
		desp_f[0] = a;
		desp_f[1] = b;
		desp_s = new int[2];
		desp_s[0] = c;
		desp_s[1] = d;
		keycode = e;
		isdown = false;
	}
	public LElement fmove(LElement element)
	{
		element.x += desp_f[0];
		element.y += desp_f[1];
		return element;
	}
	
	public LElement smove(LElement element)
	{
		element.x += desp_s[0];
		element.y += desp_s[1];
		return element;
	}
	
}
