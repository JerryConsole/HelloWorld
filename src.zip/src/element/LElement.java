package element;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;

import javax.imageio.ImageIO;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LElement implements ImageObserver {
	
	public int x;
	public int y;
	public Vector<LShape> shapes;
	public Vector<LArea> areas;
	public int healthpointlimit;
	
	public boolean visible = true; 
	
	public LElement(JSONObject jsoninput) throws FileNotFoundException, IOException {
		
		visible = true;
		x = jsoninput.getInt("x");
		y = jsoninput.getInt("y");
		
		JSONArray array = jsoninput.getJSONArray("shapes");
		shapes = new Vector<LShape>();
		for(int i = 0;i < array.length();i++)
			shapes.add(new LShape(array.getJSONObject(i)));
		
		areas = new Vector<LArea>();
		if(jsoninput.has("areas"))
		{
			array = jsoninput.getJSONArray("areas");
			for(int i = 0;i < array.length();i++)
				areas.add(new LArea(array.getJSONObject(i)));
		}
		
		if(jsoninput.has("healthpointlimit"))
		{
			healthpointlimit = jsoninput.getInt("healthpointlimit");
			System.out.println("gethealthpointlimit");
		}
		
	}
		
	public LElement() {visible = true;}

	public void draw(Graphics g)
	{
		for(LShape s:shapes)
			s.drawOn(g,x, y);
	}

	@Override
	public boolean imageUpdate(Image img, int infoflags, int x, int y,
			int width, int height) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public boolean isInArea(int ix, int iy)
	{
		if(areas != null)
		{
			for(LArea a : areas)
			{
				if(a.isInArea(ix, iy))
				{
					return true;
				}
			}
		}
		return false;
	}

	public static Vector<LElement> getVector(JSONArray jsonArray) throws FileNotFoundException, JSONException, IOException {
		Vector ret = new Vector<LElement>();
		for(int i = 0;i < jsonArray.length();i++)
		{
			ret.add(new LElement(jsonArray.getJSONObject(i)));
		}
		return ret;
	}
	
	

	public LElement clone()
	{
		LElement a = new LElement();
		if(shapes != null)
		{
			a.shapes = (Vector) shapes.clone();
		}
		a.x = x;
		a.y = y;
		a.areas = areas;
		return a;
	}
	public LElement clone(int q, int w)
	{
		LElement a = new LElement();
		if(shapes != null)
		{
			a.shapes = (Vector) shapes.clone();
		}
		a.x = q + x;
		a.y = w + y;
		a.areas = areas;
		return a;
	}
	
}
