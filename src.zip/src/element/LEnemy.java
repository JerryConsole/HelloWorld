package element;

import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONObject;

public class LEnemy {
	
	int[][] pathpoints;
	
	final public int START_TIME;
	final public int FINAL_TIME;
	
	final static int X_INDEX = 0;
	final static int Y_INDEX = 1;
	final static int TIME_INDEX = 2;

	LElement element;
	LElement element_mode;
		
	public LEnemy(JSONObject in, LElement[] elementspackage)
	{
		pathpoints = getPathPoint(in);
		element_mode =  elementspackage[in.getInt("mode")];
		START_TIME = pathpoints[0][TIME_INDEX];
		FINAL_TIME = pathpoints[pathpoints.length-1][TIME_INDEX];
		
	}
	
	
	public LElement now(int time)
	{
		if((time > START_TIME)&&(time < FINAL_TIME))
		{
			if(element == null)
			{
				element = setPosition(element_mode.clone(), time);
			}
			else
			{
				element = setPosition(element, time);
			}
		}
		else
		{
			if(element != null) 
			{
				element.visible = false;
			}
		}
		return element;
	}


	protected LElement setPosition(LElement ret, int time) {
		
		
		int pointer;
		for(pointer = 0;pointer < pathpoints.length;pointer++)
		{
			if(pathpoints[pointer][TIME_INDEX] > time)
				break;
		}
		pointer--;
		int x1 = pathpoints[pointer][X_INDEX];
		int y1 = pathpoints[pointer][Y_INDEX];
		int t1 = pathpoints[pointer++][TIME_INDEX];
		int x2 = pathpoints[pointer][X_INDEX];
		int y2 = pathpoints[pointer][Y_INDEX];
		int t2 = pathpoints[pointer][TIME_INDEX];
		
		ret.y = x1 + ((x2-x1)/(t2-t1))*(time-t1);
		ret.x = y1 + ((y2-y1)/(t2-t1))*(time-t1);
		
		return ret;
	}

	protected static int[][] getPathPoint(JSONObject in)
	{
		int[][] ret;
		int l,w;
		JSONArray array = in.getJSONArray("pathpoints");
		l = array.length();
		w = array.getJSONArray(0).length();
		ret = new int[l][w];
		for(int i = 0;i < l;i++)
		{
			for(int j = 0;j < w;j++)
			{
				ret[i][j] = array.getJSONArray(i).getInt(j);
			}
		}
		return ret;
		
	}
	
	public boolean isInArea(LElement plane)
	{
		if(element != null) 	
		{
			return element.isInArea(plane.x - element.x,  plane.y - element.y);
		}
		else 
			return false; 
	}
	
	public boolean canremove(int time)
	{
		if(time > FINAL_TIME)
			return true;
		
		return false;
	}
}
