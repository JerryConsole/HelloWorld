package element;

import org.json.JSONObject;

import element.LShape.ShapeType;

public class LArea {
	
	enum ShapeType{rect, cir, arc};
	
	int[] points;
	ShapeType type;
	ShapeType rect = ShapeType.rect;
	ShapeType cir = ShapeType.cir;
	ShapeType arc = ShapeType.arc;
	
	
	
	public LArea(JSONObject input)
	{
		switch(input.getString("shapetype"))
		{
		case "rect":
			type = rect;
			points = new int[2];
			points[0] = input.getInt("p0");
			points[1] = input.getInt("p1");
			break;
		case "cir":
			type = cir;
			points = new int[1];
			points[0] = input.getInt("p0");
			break;
		case "arc" :
			type = arc;
			points = new int[6];
			points[0] = input.getInt("p0");
			points[1] = input.getInt("p1");
			points[2] = input.getInt("p2");
			points[3] = input.getInt("p3");
			points[4] = input.getInt("p4");
			points[5] = input.getInt("p5");
			break;
		}
	}
	
	public boolean isInArea(int x, int y)
	{
		switch(type)
		{
		case arc:
			break;
		case rect:
			if(x < points[0] && x > (-points[0]) && y < points[1] && y > (-points[1]))
				return true;
			break;
		case cir:
			if(Math.sqrt(x*x+y*y) < points[0])
				return true;
			break;
		}
		return false;
	}
	
}
