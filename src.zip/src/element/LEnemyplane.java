package element;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LEnemyplane extends LEnemy{
	
	LShoot[] shoots;
	
	int healthpoint;
	
	public LEnemyplane(JSONObject in, LElement[] elementspackage) throws JSONException, FileNotFoundException, IOException
	{
		super(in, elementspackage);
		
		shoots = new LShoot[in.getJSONArray("shoots").length()];
		
		JSONArray inputshoots = in.getJSONArray("shoots");
		for(int i = 0;i < shoots.length;i++)
		{
			shoots[i] = new LShoot(inputshoots.getJSONObject(i), elementspackage);
		}
		
		healthpoint = element_mode.healthpointlimit;
	}
	
	public Vector<LEnemy> shoot(int time)
	{

		Vector<LEnemy> ret = new Vector<LEnemy>();
		if(shoots == null)
		{	
			return ret;
		}
		for(LShoot s : shoots)
		{
			if(s.START_TIME == time)
			{
				ret.addElement(s);
			}
		}
		return ret;
	}
	public boolean canremove(int time)
	{
		System.out.println(healthpoint);
		
		if(time > FINAL_TIME)
			return true;
		if(healthpoint < 0)
		{
			shoots = null;
			return true;
		}
		return false;
	}
	
	public LElement now(int time)
	{
		if((time > START_TIME)&&(time < FINAL_TIME) && (!canremove(time)))
		{
			if(element == null)
			{
				element = setPosition(element_mode.clone(), time);
			}
			else
			{
				element = setPosition(element, time);
			}
		}
		else
		{
			if(element != null) 
			{
				element.visible = false;
			}
		}
		return element;
	}
	
	public void hurt(Vector<LElement> shoots, int dmg)
	{
		if(element != null)
		{
			for(LElement s :shoots)
			{
				if(s.isInArea(s.x - element.x,  s.y - element.y))
					healthpoint -= dmg;
			}
		}
	}
}
