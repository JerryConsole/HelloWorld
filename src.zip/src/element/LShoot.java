package element;

import org.json.JSONObject;

public class LShoot extends LEnemy{
	
	
	public LShoot(JSONObject in, LElement[] elementspackage) {
		super(in, elementspackage);
	}
	
}
