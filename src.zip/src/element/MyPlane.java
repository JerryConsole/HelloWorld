package element;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;

import org.json.JSONException;
import org.json.JSONObject;

import control.LGameEvent;

public class MyPlane {

	public LGameEvent listener;

	public LElement[] plane;

	public Vector<LElement> shotss;
	public Vector<LElement> shotsf;

	Vector<LElement> elements;
	
	public LElement planeshotf; //final
	public LElement planeshots; //final
	
	public MyPlane (JSONObject in_plane) throws FileNotFoundException, JSONException, IOException 
	{
		plane = new LElement[2];
		plane[0] = new LElement(in_plane.getJSONObject("fast"));
		plane[1] = new LElement(in_plane.getJSONObject("slow"));
		planeshotf =  new LElement(in_plane.getJSONObject("planeshotf"));
		planeshots =  new LElement(in_plane.getJSONObject("planeshots"));
		plane[0].x = 300;
		plane[0].y = 300;
		listener = new LGameEvent(in_plane.getInt("fspeed"), in_plane.getInt("sspeed"));
		shotss = new Vector<LElement>();
		shotsf = new Vector<LElement>();
	}
	
	public void setElements(Vector e)
	{
		elements = e;
	}
	
	public void movePlane() {
		listener.move(plane[0]);
		
		if(listener.isshot)
		{
			if(listener.isshift)
			{
				LElement a = planeshots.clone(plane[0].x, plane[0].y);
				shotss.add(a);
				elements.add(a);
			}
			else
			{
				LElement a = planeshotf.clone(plane[0].x, plane[0].y);
				shotsf.add(a);
				elements.add(a);
			}
		}
		
		for(LElement shot :shotss)
		{
			shot.x += planeshots.x;
			shot.y += planeshots.y;
			if(shot.y < -100)
				elements.remove(shot);
		}
		for(LElement shot :shotsf)
		{
			shot.x += planeshotf.x;
			shot.y += planeshotf.y;
			if(shot.y < -100)
				elements.remove(shot);
		}
		
		if(listener.isshift)
		{
			plane[1].x = plane[0].x;
			plane[1].y = plane[0].y;
			if(elements.remove(plane[0]))
			{
				elements.add(plane[1]);
			}
		}
		else
		{
			if(elements.remove(plane[1]))
			{
				elements.add(plane[0]);
			}
		}
	}
}
