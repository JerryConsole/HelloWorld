package element;

import java.util.Date;

public class Timer {
	private long lasttime;
	
	Date data;
	public Timer()
	{
		data = new Date();
		mark();
	}
	
	public void mark()
	{
		lasttime = data.getTime();
	}
	
	public void stay(long time) 
	{
		if(lasttime + time - data.getTime() > 1)
		{
			try {
				Thread.sleep(lasttime + time - data.getTime());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		mark();
	}
	
}
