package control;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.xml.bind.Marshaller.Listener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import view.GameFrame;
import view.LGamePanel;
import view.LSelectPanel;
import element.LElement;
import element.LEnemy;
import element.LEnemyplane;
import element.LShoot;
import element.MyPlane;
import element.Timer;

public class GameControl implements Runnable{
	
	Timer timer;
	int time = 0;
	boolean alive = true;
	
	Thread thread;
	GameFrame frame;
	LSelectPanel gamepanel;
	MyPlane myplane;
	LScoreControl scorepanel;
	
	Vector<LElement> elements;
	Vector<LElement> usinggamebackground;
	Vector<LElement> cover;
	
	Vector<LEnemyplane> enemyplane;
	Vector<LEnemy> enemy;
	
	
	final static int TIMETAB = 20;	
	
	
	public GameControl(int[] choise, SelectControl selectControl) {
		
		timer = new Timer();
		
		frame = selectControl.frame;
		elements = new Vector<LElement>();
		gamepanel = selectControl.selectpanel;
		gamepanel.setElement(elements);
		
		load(choise);		
		timer.stay(1000);
		thread = new Thread(this);
		thread.start();
	}

	private void load(int[] choise) {
		try {
			JSONObject input = new JSONObject(new JSONTokener(new FileInputStream(new File("gamefile.txt"))));
			
			loadBackground(input.getJSONObject("background"));
			
			loadPlane(input.getJSONArray("planes").getJSONObject(choise[1]));
			
			loadEnemy(new JSONObject(new JSONTokener(new FileInputStream(new File(input.getJSONArray("difficulty").getString(choise[0]))))));
			
		} catch (JSONException | IOException e) {
			JOptionPane.showConfirmDialog(new JFrame(), e.toString(), "WARNING", JOptionPane.CLOSED_OPTION);
			e.printStackTrace();
			System.exit(0);

		} 
	}
	
	private void loadBackground(JSONObject in) throws FileNotFoundException, JSONException, IOException {
		usinggamebackground = new Vector<LElement>();
		LElement e = new LElement(in.getJSONArray("stagebackground").getJSONObject(0));		
		usinggamebackground.add(e);
		gamepanel.setBackgroundElement(usinggamebackground);
		
		cover = new Vector<LElement>();
		cover.add(new LElement(in.getJSONObject("coverbackground")));
		gamepanel.setcoverelement(cover);
		
		scorepanel = new LScoreControl(in, this);
		
	}

	private void loadPlane(JSONObject in_plane) throws FileNotFoundException, JSONException, IOException {
		myplane = new MyPlane(in_plane);
		myplane.setElements(elements);
		myplane.listener.setgamecontrol(this);
		gamepanel.setFocusable(true);
		gamepanel.requestFocus();
		gamepanel.addKeyListener(myplane.listener);
		elements.addElement(myplane.plane[0]);
		
	}

	private void loadEnemy(JSONObject in) throws FileNotFoundException, JSONException, IOException {
		
		Vector<LElement> enemymode = new Vector<LElement>();
		JSONArray mode = in.getJSONArray("enemymode");
		for(int i = 0;i < mode.length();i++)
		{
			enemymode.add(new LElement(mode.getJSONObject(i)));
		}

		JSONArray plane = in.getJSONArray("enemyplanes");
		enemyplane = new Vector<LEnemyplane>();
		enemy = new Vector<LEnemy>();
		
		for(int i = 0;i < plane.length();i++)
		{
			LEnemyplane a = new LEnemyplane(plane.getJSONObject(i), enemymode.toArray(new LElement[0]));
			enemyplane.add(a);
		}
		enemy.addAll(enemyplane);
	}

	public void run() {
		try {
			while(!myplane.listener.pause)
			{
				move();		
				frame.repaint();
				timer.stay(TIMETAB);
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
			System.exit(0);
		}
	}
	
	private void move() {
		movePlane();
		moveEnemy();
		time++;
		System.out.println(time);
	}

	private void moveEnemy() {
		Vector<LEnemy> remove = new Vector<LEnemy>();
		for(LEnemy e : enemy)
		{
			elements.add(e.now(time));
			if(e.canremove(time))remove.add(e);
			if(e.isInArea(myplane.plane[0]))die();
		}
		for(LEnemy r : remove)
		{
			enemy.remove(r);
		}
		for(LEnemyplane p : enemyplane)
		{
			Vector<LEnemy> e = p.shoot(time);
			if(e != null)
				enemy.addAll(e);
			p.hurt(myplane.shotss, myplane.planeshots.healthpointlimit);
			p.hurt(myplane.shotsf, myplane.planeshotf.healthpointlimit);
		}
	}

	private void movePlane() {
		myplane.movePlane();
	}
	
	private void die()
	{
		System.out.println("die");
		//System.exit(0);
	}
}
