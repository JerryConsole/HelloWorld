package control;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;
import java.util.prefs.BackingStoreException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import element.LElement;
import view.*;

public class SelectControl {
	
	GameFrame frame;
	LSelectPanel selectpanel;
	GameControl gamecontrol;
	SelectEvent selectevent;
	
	Vector<LElement> elements;
	JSONObject jsonin;
	JSONObject jsonselectpage;
	
	LElement background0;
	LElement background1;
	LElement background_wait;
	Vector<LElement> choises;
	Vector<LElement> choises_selected;
	
	
	int selected = 0;
	int selectpart = 0;
	int choise[];
	boolean isloading;
	
	
	public SelectControl()
	{
		isloading = true;
		frame = new GameFrame();
		selectpanel = new LSelectPanel();
		frame.add(selectpanel);

		try {
			loadStart();
			loadAll();
			Thread.sleep(1000);
			isloading = false;
		} catch (JSONException | IOException | InterruptedException  e) {
			JOptionPane.showConfirmDialog(new JFrame(), e.toString(), "WARNING", JOptionPane.CLOSED_OPTION);
			e.printStackTrace();
		}
		setselectpanel();
	}
	
	private void loadStart() throws JSONException, IOException
	{
		isloading = true;
		jsonin = new JSONObject(new JSONTokener(new FileInputStream(new File("mainfile.txt"))));
		JSONObject jsondevicon = jsonin.getJSONObject("devicon");
		elements = new Vector<LElement>();
		elements.add( new LElement(jsondevicon));
		selectpanel.setElement(elements);
		frame.repaint();
	}

	private void loadAll() throws FileNotFoundException, JSONException, IOException {
		
		jsonselectpage = jsonin.getJSONObject("selectpage");
		background0 = new LElement(jsonselectpage.getJSONObject("background0"));
		background1 = new LElement(jsonselectpage.getJSONObject("background1"));
		background_wait = new LElement(jsonselectpage.getJSONObject("background_wait"));
		choises = LElement.getVector(jsonselectpage.getJSONArray("choises"));
		choises_selected = LElement.getVector(jsonselectpage.getJSONArray("choises_selected"));
		choise = new int[5];
		selectpart = 0;
		selected = 0;
	}
	
	private void setselectpanel() {
		selectpanel.setElement(elements = new Vector<LElement>());
		elements.addElement(background0);
		elements.addAll(choises);
		
		selectevent = new SelectEvent(this);
		selectpanel.addKeyListener(selectevent);
		selectpanel.requestFocus();
		elements.remove(choises.elementAt(0));
		elements.add(choises_selected.elementAt(0));
		
		frame.repaint();
	}
	
	//all above run together, when created.

	private void startGame() 
	{
	//	frame.setVisible(false);
	//	JOptionPane.showConfirmDialog(new JFrame(), "��ʵ����û����Ϸ", "PAUSE", JOptionPane.CLOSED_OPTION);	
	//	System.exit(0);

		selectpanel.removeKeyListener(selectevent);
		selectpanel.setFocusable(false);
		gamecontrol = new GameControl(choise, this);
		

		
	}
	
	public void ZKeyDown() {
		System.out.println(selectpart + " " + selected);
		switch (selectpart)
		{
		case 0:
			selectpart++;
			
			switch(selected)
			{
			case 0:
				
				System.out.println("z");
				setSel("difficulty");
				break;
			case 1:
				System.exit(0);
				break;
			}
			break;
		case 1:
			choise[0] = selected;
			selected = 0;
			selectpart++;
			setSel("planes");
			break;
		case 2:
			choise[1] = selected;
			selected = 0;
			selectpart = 0;
			
			startGame();
			break;
		}
		frame.repaint();
	}
	
	private void setSel(String in)
	{
		selected = 0;
		for(int i = 0;i < elements.size();i++)
			elements.remove(i);
		elements.add(background_wait);
		frame.repaint();
		try {
			choises_selected = LElement.getVector(jsonselectpage.getJSONArray(in));
		} catch (JSONException | IOException e) {
			JOptionPane.showConfirmDialog(new JFrame(), e.toString(), "WARNING", JOptionPane.CLOSED_OPTION);
			e.printStackTrace();	
		}
		
		elements.add(background1);
		elements.add(choises_selected.elementAt(0));
	}
	
	public void UpKeyDown() {
		
		if(selectpart > 0)
		{
			if(selected > 0)
			{
				elements.remove(choises_selected.elementAt(selected));
				elements.add(choises_selected.elementAt(--selected));
			}
			else 
				return;
		}
		else
		{	if(selected > 0)
			{
				elements.remove(choises_selected.elementAt(selected));
				elements.add(choises.elementAt(selected));
				elements.remove(choises.elementAt(--selected));
				elements.add(choises_selected.elementAt(selected));
			}
		else 
			return;
		}
		frame.repaint();
	}

	public void DownKeyDown() {
		
		if(selectpart > 0)
		{
			if(selected < choises_selected.size()-1)
			{
				elements.remove(choises_selected.elementAt(selected));
				elements.add(choises_selected.elementAt(++selected));
			}
			else 
				return;
		}
		else
		{	if(selected < choises_selected.size()-1)
			{
				elements.remove(choises_selected.elementAt(selected));
				elements.add(choises.elementAt(selected));
				elements.remove(choises.elementAt(++selected));
				elements.add(choises_selected.elementAt(selected));
			}
		else 
			return;
		}
		
		frame.repaint();
	}

	public void EscEvent() {
		
		switch(selectpart)
		{
		case 0:
			if(selected != 1)
			{
				selected = 0;
				DownKeyDown();
			}
			else 
				System.exit(0);
			break;
		case 1:
			selectpart = 0;
			selected = 0;
			try {
				elements.remove(background1);
				elements.remove(choises_selected.elementAt(selected));
				
				choises_selected = LElement.getVector(jsonselectpage.getJSONArray("choises_selected"));
				choises = LElement.getVector(jsonselectpage.getJSONArray("choises"));
					
				elements.add(background0);
				elements.addAll(choises);
				elements.remove(choises.elementAt(0));
				elements.add(choises_selected.elementAt(0));
				
			} catch (JSONException | IOException e) {
				JOptionPane.showConfirmDialog(new JFrame(), e.toString(), "WARNING", JOptionPane.CLOSED_OPTION);
				e.printStackTrace();
			}
			break;
		case 2:
			selectpart = 1;
			selected = 0;
			setSel("difficulty");
			break;
		}
		frame.repaint();
	}
	
	

}
