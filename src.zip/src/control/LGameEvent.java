package control;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;

import element.LElement;
import element.LKey;

public class LGameEvent implements KeyListener{
	
	final LKey[] mkey;
	public boolean isshift;
	public boolean isshot;
	
	public boolean pause;
	GameControl gamecontrol;
	
	public LGameEvent(int f,int s)
	{
		mkey = new LKey[4];
		mkey[0] = new LKey(f, 0, s, 0, LKey.RIGHT);
		mkey[1] = new LKey(0-f, 0, 0-s, 0, LKey.LEFT);
		mkey[2] = new LKey(0, f, 0, s, LKey.DOWN);
		mkey[3] = new LKey(0, 0-f, 0, 0-s, LKey.UP);
		pause = false;
		isshift = false;
	}
	
	public void move(LElement element)
	{
		if(isshift)
		{
			for(LKey k:mkey)
			{
				if(k.isdown)
					k.smove(element);
			}
		}
		else
		{
			for(LKey k:mkey)
			{
				if(k.isdown)
					k.fmove(element);
			}
		}
		element.y = element.y > 5? element.y:5;
		element.x = element.x > 5? element.x:5;

		element.y = element.y < 605? element.y:605;
		element.x = element.x < 605? element.x:605;
	}
	
	public void setgamecontrol(GameControl g)
	{
		gamecontrol = g;
	}
	
	public void keyPressed(KeyEvent arg) {
		
		if(arg.getExtendedKeyCode() == LKey.ESC)
		{
			pause = !pause;
			if(!pause)
			{
				gamecontrol.scorepanel.contiue();
				Thread t = new Thread(gamecontrol);
				t.start();
			}
			else
			{
				gamecontrol.scorepanel.pause();
			}
		}
		
		isshift = arg.isShiftDown();
		isshot = arg.getExtendedKeyCode() == LKey.Z_KEY ? true : isshot;
		
		for(LKey k:mkey)
		{
			if(arg.getExtendedKeyCode() == k.keycode)
			{
				k.isdown = true;
				return;
			}
		}
		
		
	}

	public void keyReleased(KeyEvent arg) {

		isshift = arg.isShiftDown();

		isshot = arg.getExtendedKeyCode() == LKey.Z_KEY ? false : isshot;
		for(LKey k:mkey)
		{
			if(arg.getExtendedKeyCode() == k.keycode)
			{
				k.isdown = false;
				return;
			}
		}
	}

	public void keyTyped(KeyEvent arg) {
		if(arg.getExtendedKeyCode() == LKey.ESC)
		{
			pause = !pause;
		}
		
	}
	
	

}
