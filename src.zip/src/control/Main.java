package control;

import java.util.Vector;

import element.LElement;

public class Main {

	public static void main(String[] args) {
		new SelectControl();
	}
}
