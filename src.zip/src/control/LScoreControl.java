package control;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;

import javax.swing.JPanel;

import org.json.JSONObject;

import element.LElement;
import element.LKey;

public class LScoreControl implements KeyListener{

	Vector<LElement> overchoises;
	Vector<LElement> overchoises_selected;
	
	Vector<LElement> pausechoises;
	Vector<LElement> pausechoises_selected;
	
	LElement pauseimg;
	LElement overimg;

	int[] pauseoption;
	int[] overoption;
	
	Vector<LElement> choises;
	Vector<LElement> choises_selected;
	LElement img;
	int[] option;
	
	Vector<LElement> cover;
	
	
	int choose;
	
	int lifer;
	LElement life;
	int bombr;
	LElement bomb;
	/*
	int pointg;
	int powerg;
	int glazeg;
	*/
	GameControl gamecontrol;
	
	public LScoreControl(JSONObject in, GameControl p)
	{
		gamecontrol = p;
		cover = gamecontrol.cover;
		
		pauseoption = new int[5];
		overoption = new int[4];
		
	}
	public void pause()
	{
		gamecontrol.gamepanel.addKeyListener(this);
		gamecontrol.gamepanel.requestFocus();
		option = pauseoption;
		choises = pausechoises;
		choises_selected = pausechoises_selected;
		img = pauseimg;
		/*
		cover.add(pauseimg);
		cover.addAll(choises);
		cover.remove(choises.elementAt(0));
		cover.add(choises_selected.elementAt(0));
		*/
		choose = 0;
		
	}

	public void over()
	{
		gamecontrol.gamepanel.addKeyListener(this);
		System.exit(0);
		
	}
	
	public boolean bomb()
	{
		if(bombr > 0)
		{
			bombr--;
			return true;
		}
		return false;
	}
	
	private void choose()
	{
		gamecontrol.gamepanel.removeKeyListener(gamecontrol.myplane.listener);
		switch(option[choose])
		{
		case 0://restart
			
			break;
		case 1://backtomain
			break;
		case 2://savedata
			break;
		case 3://moretime
			break;
		case 4://contiue
			gamecontrol.gamepanel.addKeyListener(gamecontrol.myplane.listener);
			contiue();
			Thread t = new Thread(gamecontrol);
			t.start();
			break;
		}
	}
	
	public void keyPressed(KeyEvent arg0) {
		switch(arg0.getExtendedKeyCode())
		{
		case LKey.Z_KEY :
		case  LKey.ENTER:
			choose();
			break;
		case LKey.UP:
			moveSelect(1);
			break;
		case LKey.DOWN:
			moveSelect(-1);
			break;
		}
		gamecontrol.frame.repaint();
	}
	private void moveSelect(int i) {

		
		if((choose <= 0 && i == -1)||(choose >= option.length - 1 && i == 1))
			return;
		System.out.println(i);
		/*
		cover.remove(choises_selected.elementAt(choose));
		cover.add(choises.elementAt(choose));
		*/choose += i;/*
		cover.add(choises_selected.elementAt(choose));
		cover.remove(choises.elementAt(choose));
		*/
		System.out.println(choose);
		
	}
	
	public void contiue() {
		
		/*
		for(LElement e :choises)
			{cover.remove(e);}

		for(LElement e :choises_selected)
			{cover.remove(e);}
		cover.remove(img);
		*/
		gamecontrol.gamepanel.removeKeyListener(this);
	}
	
	public void keyReleased(KeyEvent arg0) {}
	public void keyTyped(KeyEvent arg0) {}
	
	
	
}
