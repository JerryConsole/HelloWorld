package control;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import element.LKey;

public class SelectEvent implements KeyListener{
	
	SelectControl selectcontrol;
	
	boolean r;
	
	
	public SelectEvent(SelectControl s)
	{
		selectcontrol = s;
		r = false;
	}
	
	
	public void keyPressed(KeyEvent arg0) {
		if(r)return;
		r = true;

		System.out.println("a" + arg0.getExtendedKeyCode() + " " + r);
		
		switch(arg0.getExtendedKeyCode())
		{
		case LKey.DOWN:
		case LKey.RIGHT:
			selectcontrol.DownKeyDown();
			break;
		case LKey.UP:
		case LKey.LEFT:
			selectcontrol.UpKeyDown();
			break;
		case LKey.Z_KEY:
		case LKey.ENTER:
			selectcontrol.ZKeyDown();
			break;
		case LKey.ESC:
			selectcontrol.EscEvent();
			break;
		}	
		r = false;
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	

}
